export interface Product {
    id: number,
    name: string,
    price: number,
    code: string,
    image: string,
    manufacturedDate: string,
    description?: string
}
