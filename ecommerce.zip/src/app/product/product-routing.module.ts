import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { ListComponent } from "./list/list.component";
import { AddComponent } from "./add/add.component";
import { UpdateComponent } from "./update/update.component";
import { ViewComponent } from "./view/view.component";

const routes: Routes = [
    { path: 'products', component: ListComponent, title: 'List Product'},
    { path: 'products/add', component: AddComponent, title: 'Add Product'},
    { path: 'products/:id/update', component: UpdateComponent, title: 'Update Product'},
    { path: 'products/:id/view', component: ViewComponent, title: 'View Product'}
]

@NgModule({
    imports: [
        RouterModule.forChild(routes)
    ]
})
export class ProductRoutingModule{

}